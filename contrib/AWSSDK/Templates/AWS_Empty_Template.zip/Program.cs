﻿using System;
using System.Configuration;
using System.Collections.Specialized;

// Add using statements to access AWS SDK for .NET services. 
// Both the Service and its Model namespace need to be added 
// in order to gain access to a service. For example, to access
// the EC2 service, add:
// using Amazon.EC2;
// using Amazon.EC2.Model;

namespace $safeprojectname$
{
    class Program
    {
        public static void Main(string[] args)
        {
            NameValueCollection appConfig = ConfigurationManager.AppSettings;

            Console.WriteLine("AWS Access Key Id {0}", appConfig["AWSAccessKey"]);
            Console.WriteLine("AWS Secret Access Key {0}", appConfig["AWSSecretKey"]);

            Console.Read();
        }
    }
}